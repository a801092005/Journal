#/bin/bash

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

STATE_OK=0
STATE_WARN=1
STATE_CRIT=2
STATE_UNKN=3

WK_DIR="/usr/local/nagios/libexec"

REPLICATION_THRESHOLD=20

REPLICATION_COUNT_COM=`curl -s -X GET "https://harbor.higgstar.com/api/v2.0/replication/executions?policy_id=4&status=Failed" -H "accept: application/json" -H "authorization: Basic YWRtaW46SGFyYm9yMTIzNDU=" -H "X-Harbor-CSRF-Token: 1irf1/HkGfgkuw0eHfsDr4Oo0d+pAh6K70aoNU60ZfnZ0vR4tm25v8luBQNQzUFtdba2VmuepDE/LC9BMbVkNw==" | jq ". | length"`

REPLICATION_LAST_TIME_COM=`curl -s -X GET "https://harbor.higgstar.com/api/v2.0/replication/executions?policy_id=4&status=Failed" -H "accept: application/json" -H "authorization: Basic YWRtaW46SGFyYm9yMTIzNDU=" -H "X-Harbor-CSRF-Token: 1irf1/HkGfgkuw0eHfsDr4Oo0d+pAh6K70aoNU60ZfnZ0vR4tm25v8luBQNQzUFtdba2VmuepDE/LC9BMbVkNw==" | jq ".[0] | .start_time"`

REPLICATION_COUNT=$REPLICATION_COUNT_COM
REPLICATION_LAST_TIME=$REPLICATION_LAST_TIME_COM

if [[ $REPLICATION_COUNT -eq $REPLICATION_THRESHOLD ]]; then
        echo "OK! Replication Count is OK!<br>Last Replication Time:"$REPLICATION_LAST_TIME"|REPLICATION_COUNT="$REPLICATION_COUNT";;"$REPLICATION_THRESHOLD
        exit $STATE_OK
else
	echo "CRITICAL! Replication Count Increase!<br>Last Replication Time:"$REPLICATION_LAST_TIME"|REPLICATION_COUNT="$REPLICATION_COUNT";;"$REPLICATION_THRESHOLD
	exit $STATE_CRIT
fi
