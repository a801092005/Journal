#!/usr/bin/python3
import re
import subprocess
import sys
from argparse import ArgumentParser, SUPPRESS

def check_item(use_parameter):
	use_ip = use_parameter.ipadd
	use_hostname = use_parameter.hostname
	use_sv_name = use_parameter.sv_name
	use_re_code = use_parameter.re_code
	use_comment = use_parameter.comment
	command = 'echo "{};{};{};{}"|/usr/local/nsca/src/send_nsca {} -d ";" -c /usr/local/nsca/sample-config/send_nsca.cfg'.format(use_hostname,use_sv_name,use_re_code,use_comment,use_ip)
	
	item_return = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
								  encoding="utf-8")
	item_return.wait(20)
	item_return_list = (item_return.communicate())
	item_status = item_return_list[0]
	item_status = re.sub('[\n]','',item_status)
	
	if "successfully" in item_status :
		message = "OK - {}|send=1".format(item_status)
		nag_alert(message,0)
	elif "Error" in item_status:
		message = "Critical - {}|send=0".format(item_status)
		nag_alert(message,2)
	else:
		message = "Unknow - {}|send=0".format(item_status)
		nag_alert(message,3)

def nag_alert(message, n_status=3):
	if n_status == 0:
		print(message)
		sys.exit(0)
	elif n_status == 1:
		print(message)
		sys.exit(1)
	elif n_status == 2:
		print(message)
		sys.exit(2)
	else:
		print(message)
		sys.exit(3)

def get_args():
	parser = ArgumentParser(prog='check_nsca_vpn.py', add_help=False,
							description="Use NSCA send an 'OK' message to inf-nagios-adm-03p")
	group = parser.add_mutually_exclusive_group(required=True)
	group.add_argument('-I', '--ip', dest='ipadd',
					   help='NSCA Server IP address')
	parser.add_argument('-H', '--host', dest='hostname',
						help='Host name')
	parser.add_argument('-S', '--service', dest='sv_name',
						help='Service name')
	parser.add_argument('-R', '--return', dest='re_code',
						default=1,
						help='Send to nagios status code,default=0')
	parser.add_argument('-C', '--comment', dest='comment',
						default="OK!",
						help='Send to nagios comment,default=OK!')
	group.add_argument('-h', '--help', default=SUPPRESS,
					   action='help',
					   help='Show this help message and exit')
	args = parser.parse_args()
	#print(args.log_file_name)
	return args

if __name__ == '__main__':
	ci = check_item(get_args())
