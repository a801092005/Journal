#/bin/bash
###
 # @Author: Jimmy.chen
 # @Date: 2022-01-19 14:23:19
 # @LastEditTime: 2022-01-20 14:17:16
 # @LastEditors: Jimmy.chen
 # @Description:  v2 透過jira插件，不需帳號密碼僅獲取mail queue 
### 

SERVER_URL='https://jira.higgstar.com'
API_PATH='rest/mailqueue/1.0/status'



GetMailStatus(){
    /usr/bin/curl -so /tmp/flusher.html -kL ${SERVER_URL}/${API_PATH} --header "X-Atlassian-Token: no-check" -H "Accept: application/json"
}

GetMailQueueStatus(){
#take mail queue 
    queue_number=$(jq .size /tmp/flusher.html)
    declare -i queue_number="${queue_number}" > /dev/null
}

GetMailErrorStatus(){
#take mail error queue 
    error_number=$(jq .errorSize /tmp/flusher.html)
    declare -i error_number="${error_number}" > /dev/null
}

    rm -f /tmp/flusher.html
    GetMailStatus
    GetMailQueueStatus
    GetMailErrorStatus
    if [[ -z ${queue_number} ]] || [[ -z ${error_number} ]];then
        echo "queue=${queue_number} err_queue=${error_number} $(date +%m%d/%H:%M) exit3|mail_queue=${queue_number} err_mail_queue=${error_number} something is empty"
        exit 3
    elif [[ ${queue_number} -le 200 ]] || [[ ${error_number} -le 200 ]];then
        echo "queue=${queue_number} err_queue=${error_number} $(date +%m%d/%H:%M) exit0|mail_queue=${queue_number} err_mail_queue=${error_number}"  
        exit 0
    elif [[ ${queue_number} -gt 200 ]] || [[ ${error_number} -gt 200 ]];then
        echo "queue=${queue_number} err_queue=${error_number} $(date +%m%d/%H:%M) exit0|mail_queue=${queue_number} err_mail_queue=${error_number}"  
        exit 1
    elif [[ ${queue_number} -gt 300 ]] || [[ ${error_number} -gt 300 ]];then
		echo "queue=${queue_number} err_queue=${error_number} $(date +%m%d/%H:%M) exit1|mail_queue=${queue_number} err_mail_queue=${error_number}"
        exit 2
    else 
        echo "Exception error exit3|queue=${queue_number} err_queue=${error_number} token=${TOKEN} "
        exit 3
    fi

