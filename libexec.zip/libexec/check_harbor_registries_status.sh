#!/bin/bash
###
 # @Author: Jimmy.chen
 # @Date: 2021-08-31 16:38:12
 # @LastEditTime: 2021-08-31 16:39:58
 # @Description: 檢查Harbor各Registries 狀態，若API回覆並未為healthy，監控會exit 1藉此監控此狀態
 # @FilePath: \backupd:\inf-git\SRE\HarborRegistriesStatusCheck.sh
### 


URL='harbor.higgstar.com'
URL_PATH="https://${URL}/api/v2.0/registries"

STATE_OK=0
STATE_CRIT=1


REG_ID=$(curl -sX GET "$URL_PATH" -H "accept: application/json" -u "hsops:Ops@5678") #get all registries id
REG_COUNT=$(curl -sX GET "$URL_PATH" -H "accept: application/json" -u "hsops:Ops@5678"|jq -r '.[] | .id'|wc -l) # get all registries count
row_count=0
for row0 in $(echo ${REG_ID} | jq -r '.[] | .id')
do
  REG_SEARCH=$(curl -sX GET "${URL_PATH}/${row0}" -H "accept: application/json" -u "hsops:Ops@5678") #get all registries id
  for row1 in $(echo ${REG_SEARCH}  | jq -r '. | @base64')
  do
    _jq() {
        echo ${row1} | base64 --decode | jq -r ${1}
    }
    REG_NAME=$(_jq '.name')
    REG_STATUS=$(_jq '.status')
  done
  #row_count=0
  if [[ $REG_STATUS == "healthy" ]]; then
    (( row_count++ ))
  fi
done
#echo $row_count $REG_COUNT
if [[ $row_count -eq $REG_COUNT ]];then
  echo "Harbor:${URL} Replications REPO Status OK!"
  exit ${STATE_OK}
else
  echo "Harbor:${URL} Replications REPO Status Need CHECK!"
  exit ${STATE_CRIT}
fi
