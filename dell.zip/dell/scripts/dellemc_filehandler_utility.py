import os
from dellemc_device_data_extractor import write_log

def get_file_path(path,filename):
    
        return os.path.join(path, filename)


def read_device_file(filename):
    
        with open(filename) as file:
            file_contents = file.read()
            return file_contents


def read_file(filename):
    try:
        with open(filename) as file:
            file_contents = file.read()
            return file_contents
    except IOError as err:
        write_log("Error occured while reading file".format(err), "error")



def write_file(filename,content):
    try:
        with open(filename, "w+") as fh:
            fh.write(content)
    except IOError as err:
        write_log("Error occured while reading file".format(err), "error")


def list_all_files(dir):
    return os.listdir(dir)


def checkAllFilesExist(filenameList, location):
    if (not filenameList):
        return False
    else:
        for filename in filenameList:
            if (not check_file_exists_at_loc(filename, location)):
                return False
        return True


def check_file_exists_at_loc(filename, dir):
    isFileExist = False
    isFileExist = os.path.exists(create_file_path(filename, dir))
    return isFileExist


def create_file_path(filename, dir):
    filename = filename + ".cfg"
    filePath = os.path.join(dir, filename)
    return filePath


def read_propfile(filepath):
    sep = '='
    comment_char = '#'
    props = {}
    with open(filepath, "rt") as f:
        for line in f:
            l = line.strip()
            if l and not l.startswith(comment_char):
                key_value = l.split(sep)
                key = key_value[0].strip()
                value = sep.join(key_value[1:]).strip().strip('"')
                props[key] = value
        f.close()
    return props

