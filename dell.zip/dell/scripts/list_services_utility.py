
#############################################################################################
#Title: ist_services_utility
#Version:3.1
#Creation Date: 10-Dec-2019
#Author : Priyanka Patil
#Description: list_services_utility.py is used to list the available services for at host and hostgroup level.
# Copyright (c) 2018 - 2019 Dell Inc. or its subsidiaries. All rights reserved. Dell, EMC,
# and other trademarks are trademarks of Dell Inc. or its subsidiaries.
# Other trademarks may be trademarks of their respective owners.
############################################################################################
import nagios_properties
from dellemc_filehandler_utility import create_file_path,read_file, check_file_exists_at_loc
import re
from dellemc_device_data_extractor import write_log, check_preReq
import nagios_constants
import nagios_messages
from regex_utility import search_component_services


def list_services_host(host,cfg_location):
    if (not check_file_exists_at_loc(host, cfg_location)):
        output_message = nagios_messages.list_host_failed_not_disc.format(host)
        write_log(" {}".format(output_message), "debug")
    else:
            filename = create_file_path(host,cfg_location)
            objectfile_content = read_file(filename)
            if(not objectfile_content):
                output_message = nagios_messages.list_cfg_not_found
            else:
                component_list,disabled_component_list = search_component_services(objectfile_content)
                enabled_component_list =[component for component in component_list
                                         if component not in disabled_component_list]
                output_message = nagios_messages.list_host_success.format(host)
                output_message += nagios_messages.list_host_success_en.format(
                    get_sorted_services(enabled_component_list))
                output_message += nagios_messages.list_host_success_dis.format(
                    get_sorted_services(disabled_component_list))
    return output_message

def list_services_hostgroup(hostgroup):
    service_list = []
    output_message = ""
    service_list = get_hostgroup_services(hostgroup)
    sorted_service_list = get_sorted_services(service_list)
    if (len(service_list) > 0):
        output_message = nagios_messages.list_hostgrp_success.format(hostgroup)
        output_message += "{}".format(sorted_service_list)
    else:
        output_message = nagios_messages.list_hostgrp_failed.format(hostgroup)

    return output_message


def get_comp_name(device_type ,key):
    component = None
    try:
        if key in ['warranty','Trap' ,'TrapG']:
            component = get_soft_comp(key)
        elif key == 'Subsystem' and device_type in ['MDArray', 'F10','F10NG', 'NSeries'] or \
            key == 'Subsystem_Mgmt' and device_type in ['Compellent']:
            component = "System"
        elif key == 'Subsystem' and device_type in ['EqualLogic']:
            component = "Member"
        elif key == 'Subsystem_Ctrl' and device_type in ['Compellent']:
            component = "Controller"
        else:
            component = key
    except Exception as unhadledExce:
        write_log("can not get installed java version{}".format(unhadledExce), "error")
    return component

def get_soft_comp(key):
    comp_name = None
    if key == "warranty":
        if (check_preReq("java")):
            comp_name = key
    elif key in ['Trap' ,'TrapG']:
        if (check_preReq("snmptt")):
            comp_name = key
    return comp_name

def get_hostgroup_services(hostgroup):
    device_type_list = []
    service_list = []
    for key, value in nagios_properties.device_data.items():
        if (hostgroup in (value.get("hostgroup"), value.get("hostgroupXC"), value.get("hostgroupVxRail"),value.get("hostgroupVxFlex"))):
            device_type_list.append(key)

    for device_type in device_type_list:
        if (device_type):
            services = nagios_properties.dell_device_services.get(device_type)
            for key, value in services.items():
                component = get_comp_name(device_type ,key)
                if (component and component not in service_list):
                    service_list.append(component)
    return service_list

def get_sorted_services(services):
    sorted_services = []
    if(services):
        sorted_services = list(set(services))
        sorted_services.sort()
    else:
        sorted_services = ['Nil']
    return sorted_services
