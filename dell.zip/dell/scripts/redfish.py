# -*- coding: utf-8 -*-

# Dell EMC OpenManage Nagios Modules
# Version 3.1
# Copyright (C) 2019 Dell Inc. or its subsidiaries. All Rights Reserved.
# author : Sachin Apagundi
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:

#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.

#    * Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
import re
from enum import Enum

import label_attr_mapping
import nagios_constants
from dellemc_device_data_extractor import write_log
from redfish_helper import RedfishHelper
from restapiendpoint import ProcessRequest
from enum import Enum


fetch_member_url = ["/redfish/v1/Systems/System.Embedded.1", "/redfish/v1/Managers/iDRAC.Embedded.1", "/redfish/v1/Chassis/System.Embedded.1"]


class Components(Enum):
    """
    List of components supported for the Idrac implementation
    format of Enum is as follows
    componentname = methodname
    """
    System = 'system'
    Subsystem = 'subsystem'
    Sensors_Fan = 'fan'
    PowerSupply = 'psu'
    Memory = 'memory'
    NIC = 'nic'
    IDRAC = 'idrac'
    CPU = 'processor'
    Controller = 'controllers'
    Disk = 'disk'
    Enclosure = 'enclosure'
    Sensors_Voltage = 'voltagesensor'
    Sensors_Temperature = 'temperaturesensor'
    Sensors_Intrusion = "intrusionsensor"
    GPU = "gpu"
    FC = "fc"
    PhysicalDisk = 'physicaldisk'
    VirtualDisk = 'virtualdisk'
    VFlash = 'vflash'

class RedFishResponseAttributes(Enum):
    """
    List Redfish Response Attributes
    """
    Chassis = 'Chassis'
    System = 'Systems'
    Members = 'Members'
    Links = 'Links'
    Managers = "Managers"


class RedFishImpl(object):
    """Handles iDRAC Redfih API requests"""

    def __init__(self, module_params=None):
        self.module_params = module_params
        self.username = self.module_params["username"]
        self.password = self.module_params["password"]
        self.fetch_all_members = self.module_params.get("fetchAllMembers",False)
        self.root_uri = "/redfish/v1/"
        self.auth_url = "Sessions"
        self.end_url = "Sessions/{Id}"
        self.process_request = ProcessRequest(module_params=module_params)
        self.auth_token = None
        self.auth_id = None
        self.headers = None
        self.odata_id = '@odata.id'
        self.method_name =  "get_{method}_details"
        self.root_resp = None
        self.system_resp = None
        self.chassis_resp = None
        self.managers_resp = None
        self.sys_emb_resp = []
        self.chassis_emb_resp = []
        self.managers_emb_resp = []
        self.expand_param = "$expand=*($levels=1)"
        self.chassis_string = "$expand=*($levels=1)"
        self.helper = RedfishHelper()

    def __enter__(self):
        """
        call invoked internally by the Object creation and call authentication of redfish to get
        session id and token
        :return: self : object reference to itself
        """
        body = {
            'UserName': self.username,
            'Password': self.password
        }
        url = self.root_uri + self.auth_url
        # Log Getting Auth Data
        resp = self.process_request.invoke_post(url, payload=body)
        if resp and resp.success:
            self.auth_token = resp.headers.get("X-Auth-Token")
            self.auth_id = resp.json_data.get("Id")
            self.headers = {"X-Auth-Token": self.auth_token}
        return self

    def _get_base_root_details(self):
        """
        handles a request to get the root response (redfish/v1) of redfish api
        and get if expand query is supported or not
        :return:
        """
        if self.root_resp is None:
            resp = self.process_request.invoke_get(self.root_uri, headers=self.headers)
            if resp and resp.success:
                self.root_resp = resp.json_data
                self.expand_query = self.root_resp.get('ProtocolFeaturesSupported', None) \
                                and self.root_resp.get('ProtocolFeaturesSupported', None).get('ExpandQuery') \
                                and self.root_resp.get('ProtocolFeaturesSupported', None).get('ExpandQuery', None).get(
                'ExpandAll', None)

    def _get_base_device_details(self, base_device):
        """
        handles a request to get the base response of redfish Systems oR Chassis.
        :param base_device: base_device can be System or Chassis
        Chassis : redfish/v1/Chassis/
        System : redfish/v1/Systems/
        :return:
        """
        base_resp = None
        root_base_resp = self.root_resp.get(base_device)
        root_base_resp_url = root_base_resp.get(self.odata_id)
        resp = self.process_request.invoke_get(root_base_resp_url, headers=self.headers)
        if resp and resp.success:
            base_resp = resp.json_data
        return base_resp

    def _get_base_member_details(self, base_resp, base_attr):
        """
         handles a request to get the base member response of redfish Systems or Chassis.
        :param base_resp: System or Chassis Response
        :param base_attr: Members attr inside the redfish response
        :return: bases embedded list of responses
        """
        base_emb_resp = []
        member_resp = base_resp.get(base_attr)
        for mem in member_resp:
            member_resp_url = mem.get(self.odata_id)
            if member_resp_url in fetch_member_url or self.fetch_all_members :
                resp = self.process_request.invoke_get(member_resp_url, headers=self.headers)
                if resp and resp.success:
                    base_emb_resp.append(resp.json_data)
        return base_emb_resp

    def _get_base_details(self, base_device, base_attr):
        """
         handles a request to get the base details, root, sytsem and chassis members member response of redfish Systems or Chassis.
        :param base_device: System or Chassis Response to be processed
        :param base_attr:  Members attr inside the redfish response
        :return:
        """
        base_resp = None
        base_emb_resp = []
        self._get_base_root_details()
        if self.root_resp:
            base_resp = self._get_base_device_details(base_device)
            base_emb_resp = self._get_base_member_details(base_resp, base_attr)
        return base_resp, base_emb_resp

    def _get_system_details(self):
        """
        handles a request to get the System details.
        redfish/v1/Systems/ and redfish/v1/Systems[Members]
        :return: system resp and embedded resp
        """
        if self.system_resp is None or self.sys_emb_resp is None or len(self.sys_emb_resp) is 0:
            self.system_resp, self.sys_emb_resp = self._get_base_details(RedFishResponseAttributes.System.value,
                                                                         RedFishResponseAttributes.Members.value)

    def _get_chassis_details(self):
        """
        handles a request to get the Chassis details.
        redfish/v1/Chassis/ and redfish/v1/Chassis[Members]
        :return: chassis resp and embedded resp
        """
        if self.chassis_resp is None or self.chassis_emb_resp is None or len(self.chassis_emb_resp) is 0:
            self.chassis_resp, self.chassis_emb_resp = self._get_base_details(RedFishResponseAttributes.Chassis.value,
                                                                              RedFishResponseAttributes.Members.value)
    def _get_managers_details(self):
        """
        handles a request to get the Chassis details.
        /redfish/v1/Managers/ and /redfish/v1/Managers/[Members]
        :return: manager resp and embedded resp
        """
        if self.managers_resp is None or self.managers_emb_resp is None or len(self.managers_emb_resp) is 0:
            self.managers_resp, self.managers_emb_resp = self._get_base_details(RedFishResponseAttributes.Managers.value,
                                                                              RedFishResponseAttributes.Members.value)

    def _get_attributes_json(self,manager_json,attr_type):
        try:
            conf_attr = {}
            attr_json = manager_json['Links']['Oem']['Dell']['DellAttributes']
            for attr in attr_json:
                if(attr_type in attr.get(self.odata_id)):
                    attr_url = attr.get(self.odata_id)
                    resp_comp = self.process_request.invoke_get(attr_url, headers=self.headers)
                    if resp_comp and resp_comp.success:
                        conf_attr = resp_comp.json_data.get("Attributes")
        except KeyError as kerr:
            write_log("Key Error in _get_attributes_json","error")
        except AttributeError as aerr:
            write_log("AttributeError Error in _get_attributes_json","error")

        return  conf_attr


    def _get_base_redfish(self):
        redfish_json = None
        try:
            attr_url = "/redfish/v1"
            resp_comp = self.process_request.invoke_get(attr_url, headers=self.headers)
            if resp_comp and resp_comp.success:
                redfish_json = resp_comp.json_data
        except Exception as kerr:
            write_log("Key Error in _get_attributes_json","error")

        return redfish_json

    def _get_comp_base_resp(self, device_emb_resp, comp_attr, link_attr, expand_attr, expand):
        """
        handles a request to get comp details via expand query, non-expand query and legacy way of looping
        :param device_emb_resp: system or chassis embedded response from Members
        :param comp_attr: attribute to be picked up from the resp after expand query, non-expand request
        :param link_attr: attribute to be picked up from the links response
        :param expand_attr: attribute to be picked up from the resp for expand query, non-expand request
        :param expand: attribute to decide if expand query is required or not
        :return: returns the list of components
        """
        comp_resp = []
        for device_resp in device_emb_resp:
            if device_resp.get(expand_attr, None):
                resp_comp_url = device_resp.get(expand_attr, None)
                qp = None
                if expand and self.expand_query:
                    qp = self.expand_param
                resp_comp = self.process_request.invoke_get(resp_comp_url.get(self.odata_id), headers=self.headers,
                                                            query_param=qp)
                if resp_comp and resp_comp.success:
                    comp_resp = comp_resp + resp_comp.json_data.get(comp_attr)
            elif device_resp.get(RedFishResponseAttributes.Links.value, None) \
                    and device_resp.get(RedFishResponseAttributes.Links.value).get(link_attr, None):
                comp_list = device_resp.get(RedFishResponseAttributes.Links.value).get(link_attr)
                for comp in comp_list:
                    comp_data = self.process_request.invoke_get(comp.get(self.odata_id), headers=self.headers)
                    if comp_data and comp_data.success:
                        comp_resp.append(comp_data.json_data)
        return comp_resp

    def _get_spl_comp_resp(self,json, path,resp_attr,expand=True):
        comp_resp = None
        try:
            oid_json = self.helper.get_json_values(json,path)
            attr_url = oid_json.get(self.odata_id)
            qp = None
            if expand and self.expand_query:
                qp = self.expand_param
            resp_comp = self.process_request.invoke_get(attr_url, headers=self.headers,
                                                        query_param=qp)
            # resp_comp = self.process_request.invoke_get(attr_url, headers=self.headers)
            if resp_comp and resp_comp.success:
                comp_resp = resp_comp.json_data.get(resp_attr)
        except KeyError as kerr:
            write_log("Key Error in _get_spl_comp_resp", "error")
        except AttributeError as aerr:
            write_log("AttributeError Error in _get_spl_comp_resp", "error")
        return comp_resp

    def system_get_comp(self, expand_attr, comp_attr, link_attr, expand=False):
        """
        handles a request to get system level comp details via expand query, non-expand query and legacy way of looping
        :param expand_attr: attribute to be picked up from the resp for expand query, non-expand request
        :param comp_attr: attribute to be picked up from the resp after expand query, non-expand request
        :param link_attr: attribute to be picked up from the links response
        :param expand: attribute to decide if expand query is required or not
        :return: returns the list of components
        """
        self._get_system_details()
        return self._get_comp_base_resp(self.sys_emb_resp, comp_attr, link_attr, expand_attr, expand)

    def chassis_get_comp(self, expand_attr, comp_attr, link_attr, expand=False):
        """
         handles a request to get chassis level comp details via expand query, non-expand query and legacy way of looping
        :param expand_attr: attribute to be picked up from the resp for expand query, non-expand request
        :param comp_attr: attribute to be picked up from the resp after expand query, non-expand request
        :param link_attr: attribute to be picked up from the links response
        :param expand: attribute to decide if expand query is required or not
        :return: returns the list of components
        """
        self._get_chassis_details()
        return self._get_comp_base_resp(self.chassis_emb_resp, comp_attr, link_attr, expand_attr, expand)

    def get_system_details(self):
        """
        handles a request to get Fan details from the chassis level comp details via expand query, non-expand query and legacy way of looping
        :return: List of Fan Instance
        """

        self._get_system_details()
        emb_json = self.sys_emb_resp
        redfish_json = self._get_base_redfish()
        service_tag = redfish_json["Oem"]["Dell"]["ServiceTag"]
        self._get_managers_details()
        managers_json = self.managers_emb_resp
        manag_json = managers_json[0]
        idrac_attr_json = self._get_attributes_json(manag_json,"iDRAC.Embedded.1")
        lifecycle_attr_json = self._get_attributes_json(manag_json,"LifecycleController.Embedded.1")
        system_attr_json = self._get_attributes_json(manag_json, "System.Embedded.1")
        if(emb_json and len(emb_json)>0):
            emb_json[0]["ServiceTag"] = service_tag
            emb_json[0]["FirmwareVersion"] = manag_json.get("FirmwareVersion")
            emb_json[0]["iDRACURL"] =  self.helper.get_json_values(manag_json, "Oem.Dell.DelliDRACCard.URLString")
            emb_json[0]["SystemLockDown"] = idrac_attr_json.get("Lockdown.1.SystemLockdown",None)
            emb_json[0]["GroupStatus"] = idrac_attr_json.get("GroupManager.1.Status", None)
            emb_json[0]["GroupName"] = idrac_attr_json.get("GroupManager.1.GroupName", None)
            emb_json[0]["VirtualAddressManagementApplication"] = lifecycle_attr_json.get("LCAttributes.1.VirtualAddressManagementApplication")
            emb_json[0]["OSName"] = system_attr_json.get("ServerOS.1.OSName")
            emb_json[0]["OSVersion"] = system_attr_json.get("ServerOS.1.OSVersion")
            oem_resp = self.helper.get_oem_resp("System", emb_json[0])
            if (oem_resp):
                emb_json[0]["NodeID"] = oem_resp.get("NodeID")
                emb_json[0]["SystemGeneration"] = oem_resp.get("SystemGeneration")
                emb_json[0]["ChassisServiceTag"] = oem_resp.get("ChassisServiceTag")
        return emb_json


    def get_fan_details(self):
        """
        handles a request to get Fan details from the chassis level comp details via expand query, non-expand query and legacy way of looping
        :return: List of Fan Instance
        """
        fan_attr = "CooledBy"
        fan_expand_attr = "Thermal"
        resp_attr = "Fans"
        fan_resp = self.chassis_get_comp(fan_expand_attr, resp_attr, fan_attr)
        return fan_resp

    def get_psu_details(self):
        """
        handles a request to get PowerSupply details from the chassis level comp details via expand query, non-expand query and legacy way of looping
        :return: List of Fan Instance
        """
        psu_attr = "PoweredBy"
        psu_expand_attr = "Power"
        resp_attr = "PowerSupplies"
        psu_resp = self.chassis_get_comp(psu_expand_attr, resp_attr, psu_attr)
        for inst in psu_resp:
            input_wattage = self.helper.get_json_values(inst,'Oem.Dell.DellPowerSupplyView.Range1MaxInputPowerWatts')
            inst['InputWattage'] = input_wattage
            if (input_wattage):
                int_val = int(input_wattage)
                if(input_wattage-int_val) == 0:
                    inst['InputWattage']= int_val
                inst['InputWattage'] =  str(inst['InputWattage']) + ' W'
        for inst in psu_resp:
            reduncancy_list=[]
            reduncancy_list = inst.get('Redundancy',None)
            if reduncancy_list and len(reduncancy_list)!=0:
                inst['RedundancyStatus'] = self.helper.get_json_values(reduncancy_list[0], 'Status.Health')
        return psu_resp

    def get_processor_details(self):
        """
        handles a request to get Processor details from the system level comp details via expand query, non-expand query
        :return: List of Fan Instance
        """
        processor_attr = "Processors"
        processors_expand_attr = "Processors"
        resp_attr = "Members"
        processors_resp = self.system_get_comp(processors_expand_attr, resp_attr, processor_attr, expand=True)
        return processors_resp

    def get_controllers_details(self):
        """
               handles a request to get PowerSupply details from the chassis level comp details via expand query, non-expand query and legacy way of looping
               :return: List of Fan Instance
               """
        controller_attr = "Storage"
        controller_expand_attr = "Storage"
        resp_attr = "Members"
        storage_contr_list = []
        controlle_resp = self.system_get_comp(controller_expand_attr, resp_attr, controller_attr,expand=True)
        for member_inst in controlle_resp:
            if member_inst:
                if member_inst.get("StorageControllers"):
                    storage_contr_list.extend(member_inst.get("StorageControllers"))

        for controller in storage_contr_list:
            cache_summary = controller.get("CacheSummary",None)
            if not cache_summary:
                controller["CacheSize"] = "Not Available"
            else:
                controller["CacheSize"] = str(cache_summary.get("TotalCacheSizeMiB",None))+" "+nagios_constants.MB

        return storage_contr_list

    def get_gpu_details(self):
        gpu_resp = []
        self._get_system_details()
        emb_json = self.sys_emb_resp
        gpu_sensor_resp = self._get_spl_comp_resp(emb_json[0],"Links.Oem.Dell.DellGPUSensorCollection","Members",
                                                  expand=True)
        gpu_sensor_ids = []
        if gpu_sensor_resp:
            for sensor in gpu_sensor_resp:
                gpu_sensor_ids.append(sensor.get("Id"))
            video_coll_resp = self._get_spl_comp_resp(emb_json[0],"Links.Oem.Dell.DellVideoCollection","Members")
            for inst in video_coll_resp:
                if(inst.get("Id") in gpu_sensor_ids):
                    gpu_resp.append(inst)
        return gpu_resp

    def get_vflash_details(self):
        self._get_managers_details()
        managers_json = self.managers_emb_resp
        manag_json = managers_json[0]
        vflash_resp = self._get_spl_comp_resp(manag_json, "Links.Oem.Dell.DellvFlashCollection", "Members",
                                                  expand=True)
        for inst in vflash_resp:
            inst["CapacityMB"] = self.helper.convert_mb_to_gb(inst["CapacityMB"])
        return vflash_resp

    def get_voltagesensor_details(self):
        voltage_expand_attr = "Power"
        resp_attr = "Voltages"
        voltage_resp = self.chassis_get_comp(voltage_expand_attr, resp_attr, None, expand=True)
        return voltage_resp

    def get_temperaturesensor_details(self):
        temperature_expand_attr = "Thermal"
        resp_attr="Temperatures"
        temperature_resp = self.chassis_get_comp(temperature_expand_attr, resp_attr, None, expand=True)
        return temperature_resp

    def get_memory_details(self):
        memory_expand_attr = "Memory"
        resp_attr = "Members"
        memory_resp = self.system_get_comp(memory_expand_attr, resp_attr, None, expand=True)
        GB = 1024
        for inst in memory_resp:
            inst['VolatileSizeMiB'] = int(inst['VolatileSizeMiB'] / GB)
            inst['VolatileSizeMiB'] = str(inst['VolatileSizeMiB']) + ' GB'
            inst['OperatingSpeedMhz'] = str(inst['OperatingSpeedMhz']) + ' MHz'
        return memory_resp

    def get_physicaldisk_details(self):

       physicaldisk_expand_attr = "Storage"
       resp_attr = "Members"
       storage_resp = self.system_get_comp(physicaldisk_expand_attr, resp_attr, None, expand=True)

       drive_list = []
       for storage_member in storage_resp:
           drive_list = drive_list + storage_member.get('Drives')

       physicaldisk_drive_resp = []

       for drive in drive_list:
            resp_comp_url = drive
            qp = None
            resp_comp = self.process_request.invoke_get(resp_comp_url.get(self.odata_id), headers=self.headers)

            comp_attr ='Assembly'
            if resp_comp and resp_comp.success:
                physicaldisk_drive_resp.append(resp_comp.json_data)
       return physicaldisk_drive_resp

    def get_virtualdisk_details(self):

        virtualdisk_expand_attr = "Storage"
        resp_attr = "Members"
        storage_resp = self.system_get_comp(virtualdisk_expand_attr, resp_attr, None, expand=True)
        volume_list = []

        for storage_member in storage_resp:
            if storage_member.get('Volumes',None) is not None:
                volume_list.append(storage_member.get('Volumes'))
        physicaldisk_drive_resp = []
        virtualdisk_volumemembers_resp = []
        for volume in volume_list:
            resp_comp_url = volume
            qp = None
            resp_comp = self.process_request.invoke_get(resp_comp_url.get(self.odata_id), headers=self.headers)
            if resp_comp and resp_comp.success:
                virtualdisk_volumemembers_resp.append(resp_comp.json_data)
        member_list=[]
        for eachvolume in virtualdisk_volumemembers_resp:
           if len(eachvolume.get('Members',None)) is not 0:
            member_list = member_list + eachvolume.get('Members',None)
        vd_resp = []
        for member_url in member_list:
            resp_comp = self.process_request.invoke_get(member_url.get(self.odata_id), headers=self.headers)
            if resp_comp and resp_comp.success:
                vd_resp.append(resp_comp.json_data)
        for inst in vd_resp:
            inst['CapacityBytes'] = self.helper.convert_bytes_to_gb( inst['CapacityBytes'])
        return vd_resp

    def get_nic_details(self):

        nic_expand_attr = "NetworkAdapters"
        resp_attr = "Members"
        nic_instances = []
        network_adapters = self.chassis_get_comp(nic_expand_attr,resp_attr,None,expand=True)
        if network_adapters:
            for adapter in network_adapters:
                if "NIC" in adapter.get('@odata.id'):
                    nic_ports_resp = self._get_spl_comp_resp(adapter,"NetworkPorts","Members", expand=True)
                    nic_device_resp = self._get_spl_comp_resp(adapter, "NetworkDeviceFunctions", "Members", expand=True)
                    for nic_dev in nic_device_resp:
                        nic_inst = nic_dev
                        self.helper.add_nic_port_info(nic_inst, nic_ports_resp)
                        nic_inst["ProductName"] = adapter.get("Model")
                        nic_inst["FirmwareVersion"] = self.helper.get_nic_fw_ver(adapter, nic_inst)
                        oem_resp = self.helper.get_oem_resp("NIC", nic_dev)
                        if (oem_resp):
                            nic_inst["ProductName"] = oem_resp.get("ProductName")
                            nic_inst["FirmwareVersion"] = oem_resp.get("FamilyVersion")
                        nic_instances.append(nic_inst)


        return nic_instances

    def get_fc_details(self):
        nic_expand_attr = "NetworkAdapters"
        resp_attr = "Members"
        nic_instances = []
        network_adapters = self.chassis_get_comp(nic_expand_attr,resp_attr,None,expand=True)
        if network_adapters:
            for adapter in network_adapters:
                if "FC" in adapter.get('@odata.id'):
                    nic_ports_resp = self._get_spl_comp_resp(adapter,"NetworkPorts","Members", expand=True)
                    nic_device_resp = self._get_spl_comp_resp(adapter, "NetworkDeviceFunctions", "Members", expand=True)
                    for nic_dev in nic_device_resp:
                        nic_inst = nic_dev
                        self.helper.add_nic_port_info(nic_inst, nic_ports_resp)
                        nic_inst["DeviceName"] = adapter.get("Model")
                        nic_inst["FirmwareVersion"] = self.helper.get_nic_fw_ver(adapter, nic_inst)
                        oem_resp = self.helper.get_oem_resp("FC", nic_dev)
                        if (oem_resp):
                            nic_inst["DeviceName"] = oem_resp.get("DeviceName")
                            nic_inst["FirmwareVersion"] = oem_resp.get("FamilyVersion")
                        nic_instances.append(nic_inst)


        return nic_instances


    def get_subsystem_details(self):
        """
        handles a request to get PowerSupply details from the chassis level comp details via expand query, non-expand query and legacy way of looping
        :return: List of Fan Instance
        """
        sys_overall_health = []
        self._get_system_details()
        comp_resp = self.sys_emb_resp
        health_resp = comp_resp[0]
        comp_rollup = {}
        comp_rollup["OverallRollup"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Status.HealthRollup"))
        comp_rollup["VoltRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.VoltRollupStatus"))
        comp_rollup["StorageRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.StorageRollupStatus"))
        comp_rollup["PSRollupStatus"] =\
        label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.PSRollupStatus"))
        comp_rollup["CurrentRollupStatus"] = \
        label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.CurrentRollupStatus"))
        comp_rollup["FanRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.FanRollupStatus"))
        comp_rollup["IntrusionRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.IntrusionRollupStatus"))
        comp_rollup["SysMemPrimaryStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.SysMemPrimaryStatus"))
        comp_rollup["BatteryRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.BatteryRollupStatus"))
        comp_rollup["CPURollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.CPURollupStatus"))
        comp_rollup["TempRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.TempRollupStatus"))
        comp_rollup["SDCardRollupStatus"] = \
            label_attr_mapping.status_map.get(self.helper.get_json_values(health_resp,"Oem.Dell.DellSystem.SDCardRollupStatus"))
        comp_rollup["ControllerRollupStatus"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Oem.Dell.DellSystem.ControllerRollupStatus"))
        comp_rollup["NICRollupStatus"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Oem.Dell.DellSystem.NICRollupStatus"))
        comp_rollup["FCNICRollupStatus"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Oem.Dell.DellSystem.FCNICRollupStatus"))
        comp_rollup["PhysicalDiskRollupStatus"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Oem.Dell.DellSystem.PhysicalDiskRollupStatus"))
        comp_rollup["VirtualDiskRollupStatus"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Oem.Dell.DellSystem.VirtualDiskRollupStatus"))
        comp_rollup["GPURollupStatus"] = \
            label_attr_mapping.status_map.get(
                self.helper.get_json_values(health_resp, "Oem.Dell.DellSystem.GPURollupStatus"))


        sys_overall_health.append(comp_rollup)
        return sys_overall_health

    def _get_resp_json(self, comp_resp,comp):
        resp_json = {}
        rollup = self._get_rollup_status(comp)
        resp_json[nagios_constants.COMP_RESP] = comp_resp
        resp_json[nagios_constants.ROLLUP_HEALTH] = rollup
        return resp_json


    def _get_rollup_status(self, component):
        rollup_status = None
        if not self.sys_emb_resp:
            self._get_system_details()
        system_resp = self.sys_emb_resp[0]
        if system_resp:
            rollup_field = label_attr_mapping.rollup_map.get(component)
            if rollup_field:
                rollup_status = self.helper.get_json_values(system_resp,rollup_field)
        return rollup_status

    def get_components(self, components):
        """
        returns the list of components and instance map
        :param components:
        :return:
        """
        resp = {}
        for comp in components:
            callable_method = getattr(self, self.method_name.format(method=comp.value))
            if callable(callable_method):
                resp.update({comp.name: self._get_resp_json(callable_method(),comp.name)})
        return resp




    def __exit__(self, exc_type, exc_val, exc_tb):
        """Deletes a session id, which is in use for request"""
        if self.auth_id:
            url = self.root_uri + self.end_url.format(Id=self.auth_id)
            resp = self.process_request.invoke_delete(url, headers=self.headers)
            # Log Finished cleaning up Auth Data
        return False


