import base64
import hashlib
import sys
import os
from Cryptodome import Random
from Cryptodome.Cipher import AES
import nagios_messages

current_dir = os.path.dirname(os.path.realpath(__file__))
key_min_len = 10
key_max_len = 25


class AESCipher(object):

    def __init__(self):
        self.bs = AES.block_size
        key = None

    def getKey(self):
        key_val = self.get_key_from_resource()
        if key_val is None or key_val == "":
            return nagios_messages.UNIQUE_STRING_NOT_VALID

        if key_val.startswith(nagios_messages.ERROR_STRING):
            return key_val

        if len(key_val) < key_min_len or len(key_val) > key_max_len:
            return nagios_messages.UNIQUE_STRING_NOT_VALID

        self.key = hashlib.sha256(key_val.encode()).digest()
        return self

    def encrypt(self, raw):
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        retval = base64.b64encode(iv + cipher.encrypt(raw.encode())).decode("utf-8")
        return retval

    def decrypt(self, enc):
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    def _pad(self, s):
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)

    def get_key_from_resource(self):
        omi_res = "$OMINAGIOSRESPATH$="
        resource_path = self.read_nagioshome() + "/etc/resource.cfg"
        path_loc = None
        key = ""
        data = ""

        if os.path.exists(resource_path):
            with open(resource_path, 'r') as fh:
                data = fh.read()
        else:
            return nagios_messages.RESOURCE_FILE_NOT_FOUND

        for line in data.split("\n"):
            if omi_res in line:
                path_loc = line[line.find(omi_res) + len(omi_res):]

        if path_loc is None or path_loc == "":
            return nagios_messages.UNIQUE_STRING_FILE_PATH

        if path_loc and path_loc != "":
            if os.path.exists(path_loc) and os.path.isfile(path_loc):
                with open(path_loc, 'r') as fh_1:
                    key = fh_1.read()
            else:
                return nagios_messages.UNIQUE_STRING_FILE_NOT_FOUND

        return key.strip()

    @staticmethod
    def read_nagioshome():
        nagios_home = "NAGIOS_HOME="
        nagios_home_loc = ""
        with open(current_dir + "/dellconfig.cfg", "r") as myfile:
            data = myfile.read()
        for line in data.split("\n"):
            if nagios_home in line:
                nagios_home_loc = line[line.find(nagios_home) + len(nagios_home):]
        return nagios_home_loc

    @staticmethod
    def _unpad(s):
        return s[:-ord(s[len(s)-1:])]


# required for XI
if __name__ == "__main__":
    text = sys.argv[1]
    aes = AESCipher().getKey()
    if isinstance(aes, AESCipher):
        print(aes.encrypt(text))
    else:
        print(aes)
