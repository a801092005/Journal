import re

def search_component_services(file_content):
    component_list = re.findall(r"--componentname=(.*?)\!",
                                file_content)
    return component_list

