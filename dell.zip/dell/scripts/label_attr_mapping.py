# -*- coding: utf-8 -*-

# Dell EMC OpenManage Nagios Modules
# Version 3.1
# Copyright (C) 2019 Dell Inc. or its subsidiaries. All Rights Reserved.
# author : Sachin Apagundi
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:

#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.

#    * Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
from collections import OrderedDict
#1 Node Id = SMSTC35, Chassis ServiceTag = SMSTC35, System Generation = 14G Monolithic, ServiceTag = SMSTC35,
# Model = PowerEdge R840, OS Name = Windows Server 2019, OS Version = 10.0, iDRAC URL = https://100.98.69.48:443,
# iDRAC Firmware Version = 4.00.00.00, Server Host FQDN = WIN-JF8JGQFPKEN, VMM URL = Not Available, System Configuration Lockdown Mode = Disabled,
# iDRAC Group Name = Not Available, iDRAC GroupManager Status = Disabled
system_attr = OrderedDict()
system_attr["NodeID"]= "Node Id"
system_attr["ChassisServiceTag"]= "Chassis ServiceTag"
system_attr["ServiceTag"]= "ServiceTag"
system_attr["Model"]= "Model"
system_attr["OSName"]= "OS Name"
system_attr["OSVersion"]= "OS Version"
system_attr["iDRACURL"]= "iDRAC URL"
system_attr["FirmwareVersion"]= "iDRAC Firmware Version"
system_attr["HostName"]= "Server Host FQDN"
system_attr["VirtualAddressManagementApplication"]= "VMM URL"
system_attr["SystemLockDown"]= "System Configuration Lockdown Mode"
system_attr["GroupName"]= "iDRAC Group Name"
system_attr["GroupStatus"]= "iDRAC GroupManager Status"


rollup_attr = OrderedDict()
rollup_attr["OverallRollup"]= "Overall System"
rollup_attr["VoltRollupStatus"]= "Voltage"
rollup_attr["StorageRollupStatus"]= "Storage"
rollup_attr["PSRollupStatus"]= "PowerSupply"
rollup_attr["FanRollupStatus"]= "Fan"
rollup_attr["SysMemPrimaryStatus"]= "Memory"
rollup_attr["CPURollupStatus"]= "CPU"
rollup_attr["TempRollupStatus"]= "Temperature"
rollup_attr["SDCardRollupStatus"]= "SDCard"
rollup_attr["NICRollupStatus"]= "NIC"
rollup_attr["FCNICRollupStatus"]= "FCNIC"
rollup_attr["PhysicalDiskRollupStatus"]= "Physical Disk"
rollup_attr["VirtualDiskRollupStatus"]= "Virtual Disk"
rollup_attr["GPURollupStatus"]= "GPU"
rollup_attr["ControllerRollupStatus"]= "Controller"





psu_attr = OrderedDict()
psu_attr["Status.Health"]= "Status"
psu_attr["MemberId"]= "FQDD"
psu_attr["RedundancyStatus"]= "Redundancy"
psu_attr["FirmwareVersion"]= "FirmwareVersion"
psu_attr["InputWattage"]= "InputWattage"

fan_attr = OrderedDict()
fan_attr["Status.Health"]= "Status"
fan_attr["FanName"]= "FQDD"
fan_attr["Status.State"]= "State"

nic_attr = OrderedDict()
nic_attr["LinkStatus" ]= "ConnectionStatus"
nic_attr["Id" ]= "FQDD"
nic_attr["CurrentLinkSpeedMbps" ]= "LinkSpeed"
nic_attr["FirmwareVersion" ]= "FirmwareVersion"
nic_attr["ProductName" ]= "ProductName"

fc_attr = OrderedDict()
fc_attr["LinkStatus" ]= "ConnectionStatus"
fc_attr["Id" ]= "FQDD"
fc_attr["DeviceName" ]= "Name"
fc_attr["FirmwareVersion" ]= "FirmwareVersion"
fc_attr["CurrentLinkSpeedMbps" ]= "LinkSpeed"




volt_attr = OrderedDict()
volt_attr[ "Status.Health" ]= "Status"
volt_attr["Name" ]= "Location"
volt_attr["Status.State" ]= "State"


temp_attr = OrderedDict()
temp_attr["Status.Health"]= "Status"
temp_attr["Name"]= "Location"
temp_attr["Status.State"]= "State"


mem_attr = OrderedDict()
mem_attr["Status.Health"]= "Status"
mem_attr["Id"]= "FQDD"
mem_attr["MemoryDeviceType"]= "Type"
mem_attr["PartNumber"]= "PartNumber"
mem_attr["VolatileSizeMiB"]= "Size"
mem_attr["Status.State"]= "State"
mem_attr["OperatingSpeedMhz"]= "Speed"
mem_attr["Oem.Dell.DellMemory.MemoryTechnology"]= "MemoryTechnology"


intru_attr = OrderedDict()
intru_attr["Status.Health"]= "Status"
intru_attr["Name"]= "Location"
intru_attr["Status.State"]= "State"

amp_attr = OrderedDict()
amp_attr["Status.Health"]= "Status"
amp_attr["Name"]= "Location"
amp_attr["Status.State"]= "State"

battery_attr = OrderedDict()
battery_attr["Status.Health"]= "Status"
battery_attr["Name"]= "Location"
battery_attr["Status.State"]= "State"

cpu_attr = OrderedDict()
cpu_attr["Status.Health"]= "Status"
cpu_attr["Id"]= "FQDD"
cpu_attr["Model"]= "Model"
cpu_attr["TotalCores"]= "CoreCount"

controller_attr = OrderedDict()
controller_attr["Status.Health"]= "Status"
controller_attr["MemberId"]= "FQDD"
controller_attr["CacheSize"]= "CacheSize"
controller_attr["FirmwareVersion"]= "FirmwareVersion"
controller_attr["Name"]= "Name"


gpu_attr = OrderedDict()
gpu_attr["GPUHealth"]= "Status"
gpu_attr["FQDD"]= "FQDD"
gpu_attr["FirmwareVersion"]= "FirmwareVersion"
gpu_attr["Manufacturer"]= "Manufacturer"
gpu_attr["DataBusWidth"]= "DataBusWidth"
gpu_attr["MarketingName"]= "MarketingName"
gpu_attr["SlotType"]= "SlotType"
gpu_attr["GPUState"]= "GPUState"


phys_disk_attr = OrderedDict()
phys_disk_attr["Status.Health"]= "Status"
phys_disk_attr["Id"]= "FQDD"
phys_disk_attr["Model"]= "ProductID"
phys_disk_attr["SerialNumber"]= "SerialNumber"
phys_disk_attr["CapacityBytes"]= "Size"
phys_disk_attr["MediaType"]= "MediaType"
phys_disk_attr["Revision"]= "Revision"
phys_disk_attr["Oem.Dell.DellPhysicalDisk.RaidStatus"]= "State"



virt_disk_attr = OrderedDict()
virt_disk_attr["Status.Health"]= "Status"
virt_disk_attr["Id"]= "FQDD"
virt_disk_attr["VolumeType"]= "Layout"
virt_disk_attr["CapacityBytes"]= "Size"
virt_disk_attr["Oem.Dell.DellVirtualDisk.MediaType"]= "MediaType"
virt_disk_attr["Oem.Dell.DellVirtualDisk.ReadCachePolicy"]= "ReadCachePolicy"
virt_disk_attr["Oem.Dell.DellVirtualDisk.WriteCachePolicy"]= "WriteCachePolicy"
virt_disk_attr["Oem.Dell.DellVirtualDisk.StripeSize"]= "StripeSize"
virt_disk_attr["Oem.Dell.DellVirtualDisk.RaidStatus"]= "State"

vflash_attr = OrderedDict()
vflash_attr["HealthStatus"]= "Status"
vflash_attr["DeviceDescription"]= "FQDD"
vflash_attr["CapacityMB"]= "Size"
vflash_attr["WriteProtected"]= "WriteProtected"
vflash_attr["InitializedState"]= "InitializedState"
vflash_attr["VFlashEnabledState"]= "vFalshEnabledState"



device_comp_attr_map = {
    "iDRAC": {
        "System":system_attr,
        "PowerSupply": psu_attr,
        "Sensors_Fan": fan_attr,
        "NIC":nic_attr,
        "FC": fc_attr,
        "Sensors_Voltage": volt_attr,
        "Sensors_Temperature" :  temp_attr,
        "Sensors_Intrusion" : intru_attr,
        "Memory" : mem_attr,
        "Battery" : battery_attr,
        "Sensors_Amperage" : amp_attr,
        "CPU": cpu_attr,
        "Controller": controller_attr,
        "GPU": gpu_attr,
        "PhysicalDisk":phys_disk_attr,
        "VirtualDisk": virt_disk_attr,
        "VFlash": vflash_attr,
        "Subsystem":rollup_attr
    }
}

rollup_map = {
"Subsystem": "Status.HealthRollup",
"Sensors_Fan":	"Oem.Dell.DellSystem.FanRollupStatus",
"Sensors_Voltage":	"Oem.Dell.DellSystem.VoltRollupStatus",
"CPU":	"Oem.Dell.DellSystem.CPURollupStatus",
"PowerSupply":	"Oem.Dell.DellSystem.PSRollupStatus",
"Sensors_Temperature":	"Oem.Dell.DellSystem.TempRollupStatus",
"Memory":	"Oem.Dell.DellSystem.SysMemPrimaryStatus",
"VFlash":	"Oem.Dell.DellSystem.SDCardRollupStatus",
"Sensors_Intrusion":	"Oem.Dell.DellSystem.IntrusionRollupStatus",
"Sensors_Amperage":	"Oem.Dell.DellSystem.CurrentRollupStatus"

}

status_map = { "OK" : "OK",
               "Critical":"Critical",
               "Error" : "Critical",
               "Degraded": "Warning",
               "Warning":"Warning",
               None:"Unknown"}