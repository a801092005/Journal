import  re

from dellemc_device_data_extractor import validate_ip, write_log
from device_check_exclude_instance import get_inst_name_value
from regex_utility import search_component_services
import nagios_messages
from update_services_utility import get_all_hostgroup


def validate_alphanumeric(service):
    if not re.match("^[a-zA-Z0-9_]*$", service):
        return False
    return True

def validate_service(service):
    if not re.match("^[a-zA-Z0-9_,'\"]*$", service):
        return False
    if (service.count("'")%2!=0 or service.count('"')%2 != 0):
        return False
    return True

def validate_host(host,inputport):
    max_length = 39
    if(len(host)>max_length):
        return False
    rx_ip = re.compile(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b')
    rx_hostname = re.compile(r"^[a-zA-Z0-9_.]*$")
    rx_ipv6 =  re.compile(r"^[a-zA-Z0-9_:]*$")
    result = rx_ip.match(host) or rx_hostname.match(host) or rx_ipv6.match(host)
    if(not result):
        if(not re.match("^[a-zA-Z0-9_.]*$", host)):
            return False

    try:
        resolvedAddress = validate_ip(host, inputport)
        write_log(" resolvedAddress:{}".format(resolvedAddress), "error")
    except Exception as unhEx:
        write_log("Exception occured while getting resolvedAddress:{}".format(unhEx), "error")
        resolvedAddress = None
    if (not resolvedAddress):
        return False

    return True

def validate_hostgroup(hostgroup):
    max_length = 100
    if (len(hostgroup) > max_length):
        return False
    if not re.match("^[a-zA-Z_ \-]*$", hostgroup):
        return False
    elif (not hostgroup in get_all_hostgroup()):
        return False

    return True

def validate_excl_con(excl_cond):
    valid = False
    if(len(excl_cond)>5000):
        return False
    if re.search(r'\sor\s', excl_cond, flags=re.IGNORECASE):
        excl_condns = re.split(r'\sor\s', excl_cond, flags=re.IGNORECASE)
        for cond in excl_condns:
            if(not check_valid_condition(cond)):
                return False
    else:
        if(not check_valid_condition(excl_cond)):
            return False



    return True

def check_valid_condition(cond):
    try:
        element = cond
        elementPair = []
        if re.search(r"\s?==\s?", cond, flags=re.IGNORECASE):
            elementPair = re.split(r'\s?==\s?', cond, flags=re.IGNORECASE)
        elif re.search(r"\sin\s*\(", element, flags=re.IGNORECASE):
            elementPair = get_inst_name_value(element)
        else:
            return False
        elementVals = elementPair[1].split(',')
        if not re.match("^[a-zA-Z_]*$", elementPair[0]):
            return False
        for val in elementVals:
            if(not validate_excl_vals(val)):
                return False


    except IndexError as error:
        return False
    return True

def validate_excl_vals(exclVals):
    rx_space = re.compile("\s+")
    if (re.match("^[\"]+$", exclVals)):
        return False
    if (rx_space.search(exclVals)):
        if (not ((exclVals.startswith("'") and exclVals.endswith("'")))):
            return False
    return True

def validate_services_list(text_list):
    max_list_len = 50
    max_text_len = 50
    if(len(text_list)>max_list_len):
        return False
    for text in text_list:
        if(len(text)>max_text_len):
            return False
        if( not validate_service(text)):
            return False
    return True

def validate_cmd_args(cmd_args):
    val_msg = None
    if (cmd_args.host):
        if (not validate_host(cmd_args.host,cmd_args.inputport)):
            val_msg = nagios_messages.invalid_host
            return val_msg
    if (cmd_args.hostgroup):
        if (not validate_hostgroup(cmd_args.hostgroup)):
            val_msg = nagios_messages.invalid_hostgroup
        if(not (cmd_args.addservices or  cmd_args.removeservices or  cmd_args.list_services or  cmd_args.allservices)):
            val_msg = nagios_messages.hostgroup_not_supp_cmd
        return val_msg
    if (cmd_args.hostlist and len(cmd_args.hostlist) > 0):
        for host in cmd_args.hostlist:
            if (not validate_host(host,cmd_args.inputport)):
                val_msg = nagios_messages.invalid_host_list
        return val_msg
    if(cmd_args.addservices and len(cmd_args.addservices)>0):
        if(not validate_services_list(cmd_args.addservices)):
            val_msg = nagios_messages.invalid_add_services
        return val_msg
    if (cmd_args.removeservices and len(cmd_args.removeservices) > 0):
        if (not validate_services_list(cmd_args.removeservices)):
            val_msg = nagios_messages.invalid_remove_services
        return val_msg
    if (cmd_args.exclude_instance and len(cmd_args.exclude_instance) > 0):
        if (not validate_excl_con(cmd_args.exclude_instance)):
            val_msg = nagios_messages.invalid_excl_inst
        return val_msg
    if (cmd_args.service and len(cmd_args.service) > 0):
        if (not validate_alphanumeric(cmd_args.service)):
            val_msg = nagios_messages.invalid_service
        return val_msg

    return val_msg
