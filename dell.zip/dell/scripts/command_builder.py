import nagios_messages

import nagios_properties
from dellemc_helper_utility import process_command
from list_services_utility import list_services_host, list_services_hostgroup
from update_services_utility import update_services_host, update_services_hostgroup, exclude_component_instance, \
    enable_all_services_host, enable_all_services_hostgroup, append_output_message
from dellemc_filehandler_utility import checkAllFilesExist, check_file_exists_at_loc
from dellemc_device_data_extractor import write_log, validate_ip
from validation_util import validate_cmd_args


class CommandFactory:
    def __init__(self, results, cmd_args):
        self.results = results
        self.cmd_args = cmd_args

    def load_executor(self):
        executor= None
        try:
            if (self.cmd_args.list_services):
                executor = self.get_list_executor()
            if (self.cmd_args.addservices or self.cmd_args.removeservices or self.cmd_args.allservices):
                executor = self.get_update_executor()
            if (self.cmd_args.exclude_instance):
                executor = ExcludeInstanceExecutor(self.results, self.cmd_args)
            if(not executor or self.cmd_args.force_discover):
                executor = DiscoveryExecutor(self.results, self.cmd_args)
            return executor
        except IOError as ioerror:
            write_log("Error occured during io operation :"+ioerror,"error")


    def get_update_executor(self):
        executor = None
        if (self.cmd_args.host and check_file_exists_at_loc(self.cmd_args.host, self.cmd_args.cfg_location)):
            executor = UpdateServicesHostExecutor(self.results, self.cmd_args)
        elif (self.cmd_args.hostgroup):
            executor = UpdateServicesHostGroupExecutor(self.results, self.cmd_args)
        elif (len(self.cmd_args.hostlist) > 0 and checkAllFilesExist(self.cmd_args.hostlist, self.cmd_args.cfg_location)):
            executor = UpdateServicesHostListExecutor(self.results, self.cmd_args)
        return executor


    def get_list_executor(self):
        executor = None
        if (self.cmd_args.host):
            executor = ListServicesHostExecutor(self.results, self.cmd_args)
        elif (self.cmd_args.hostgroup):
            executor = ListServicesHostGroupExecutor(self.results, self.cmd_args)
        elif (len(self.cmd_args.hostlist) > 0):
            executor = ListServicesHostListExecutor(self.results, self.cmd_args)
        return executor

    def check_valid_inputs(self):
        inval_flag = False
        inval_msg = self.validate_cmd_args()
        if (inval_msg):
            inval_flag = True
        elif(not self.check_mutually_exc_grp()):
            inval_msg = nagios_messages.mutually_excl_commands
            inval_flag = True

        return inval_msg,inval_flag

    def check_mutually_exc_grp(self):
        excl_grp_cnt = self.get_excl_cmd_cout()
        if (excl_grp_cnt > 1):
            return False
        return True

    def validate_cmd_args(self):
        val_msg = validate_cmd_args(self.cmd_args)
        return val_msg

    def get_excl_cmd_cout(self):
        excl_count = 0
        if (self.cmd_args.list_services):
            excl_count = excl_count + 1
        if (self.cmd_args.addservices or self.cmd_args.removeservices):
            excl_count = excl_count + 1
        if (self.cmd_args.exclude_instance):
            excl_count = excl_count + 1
        if (self.cmd_args.allservices):
            excl_count = excl_count + 1
        return excl_count

    def print_progress_msg(self):
        print(nagios_messages.command_exec_progress)

    def print_summary(self,executor, message):
        if(not isinstance(executor,DiscoveryExecutor)):
            if (message and len(message) > 0):
                if("[Success]" in message):
                    print(message.replace("[Success]","").strip())
                    print(nagios_messages.nagios_restart_message)
                else:
                    print(message.replace("[Failed]","").strip())


class CommandExecutor:
    def __init__(self, results, command_arguments):
        self.results = results
        self.command_arguments = command_arguments
        self.error_massge = ""
        self.success_mesage = ""

    def execute(self):
        raise NotImplementedError



class DiscoveryExecutor(CommandExecutor):

    def execute(self):
        process_command(self.results, self.command_arguments)


class UpdateServicesHostExecutor(CommandExecutor):
    def execute(self):
        output_msg = ""
        if (not check_file_exists_at_loc(self.command_arguments.host, self.command_arguments.cfg_location)):
            executor = DiscoveryExecutor(self.results, self.command_arguments)
            output_msg = executor.execute()
        else:
            if(self.command_arguments.allservices):
                output_msg = enable_all_services_host(self.command_arguments.host, self.command_arguments.cfg_location)
            else:
                output_msg = update_services_host(self.command_arguments.host, self.command_arguments.addservices,
                                              self.command_arguments.removeservices,
                                              self.command_arguments.cfg_location)
        return output_msg


class UpdateServicesHostListExecutor(CommandExecutor):
    def execute(self):
        output_msg = ""
        if (not checkAllFilesExist(self.command_arguments.hostlist, self.command_arguments.cfg_location)):
            executor = DiscoveryExecutor(self.results, self.command_arguments)
            output_msg = executor.execute()
        else:
            for host in self.command_arguments.hostlist:
                if(self.command_arguments.allservices):
                    message= enable_all_services_host(host, self.command_arguments.cfg_location)
                    output_msg = append_output_message(output_msg,message)
                else:
                    message = update_services_host(host,self.command_arguments.addservices,
                                        self.command_arguments.removeservices, self.command_arguments.cfg_location)
                    output_msg = append_output_message(output_msg,message)
        return output_msg


class UpdateServicesHostGroupExecutor(CommandExecutor):
    def execute(self):
        if (self.command_arguments.allservices):
            output_msg = enable_all_services_hostgroup(self.command_arguments.hostgroup, self.command_arguments.cfg_location)
        else:
            output_msg = update_services_hostgroup(self.command_arguments.hostgroup, self.command_arguments.addservices,
                                               self.command_arguments.removeservices,
                                               self.command_arguments.cfg_location)
        return output_msg


class ExcludeInstanceExecutor(CommandExecutor):
    def execute(self):
        if (not self.command_arguments.service):
            output_msg = nagios_messages.invalid_option_excl_inst
        else:
            output_msg = exclude_component_instance(self.command_arguments.host,
                                                    self.command_arguments.exclude_instance,
                                                    self.command_arguments.service,
                                                    self.command_arguments.cfg_location)
        return output_msg



class ListServicesHostExecutor(CommandExecutor):
    def execute(self):
        output_msg = list_services_host(self.command_arguments.host,self.command_arguments.cfg_location)
        return output_msg


class ListServicesHostGroupExecutor(CommandExecutor):
    def execute(self):
        output_message = list_services_hostgroup(self.command_arguments.hostgroup)
        return output_message


class ListServicesHostListExecutor(CommandExecutor):
    def execute(self):
        output_msg = ""
        if (not checkAllFilesExist(self.command_arguments.hostlist, self.command_arguments.cfg_location)):
            output_msg = nagios_messages.list_cfg_not_found
            write_log(" {}".format(output_msg), "debug")
        hostlist = self.command_arguments.hostlist
        for host in hostlist:
            output_msg += list_services_host(host,self.command_arguments.cfg_location)
            write_log(" {}".format(output_msg), "debug")
        return output_msg


