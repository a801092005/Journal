
#############################################################################################
#Title: dellemc_fault_info
#Version:3.1
#Creation Date: Nov-2019
#Author : Sachin Apagundi
#Description: dellemc fault information for NGM, ME4 and servers will be prossed and generated here.
# Copyright (c) 2018 - 2019 Dell Inc. or its subsidiaries. All rights reserved. Dell, EMC,
# and other trademarks are trademarks of Dell Inc. or its subsidiaries.
# Other trademarks may be trademarks of their respective owners.
############################################################################################

class NagiosFaultBuilder(object):

    # init method
    def __init__(self):
        self.data = None
        self.deviceType = None

    def setData(self, data):
        self.data = data
        return self

    def setDeviceType(self, deviceType):
        self.deviceType = deviceType
        return self

    def build(self):
        nagiosfault = NagiosFaultFactory().getInstance(self.deviceType)
        if nagiosfault:
            nagiosfault.setData(self.data)
            return nagiosfault.buildFaultString()
        return None

class NagiosFaultBase(object):

    # init method
    def __init__(self):
        self.componentType = None
        self.data = None
        self.fsb = FaultStringBuilder()

    def setData(self, data):
        self.data = data

    def buildFaultString(self):
        pass

class NagiosFaultFactory(object):

    # init method
    def __init__(self):
        self.data = None

    def getInstance(self, deviceType):
        if deviceType == "NGM":
            return NGMFaultInfo()
        if deviceType == "ME4":
            return  ME4FaultInfo()
        # Add for other device type here

class FaultStringBuilder(object):

    # init method
    def __init__(self):
        self.faultcriticaldict = {}
        self.faultwarningdict = {}
        self.wrapindex = 3

    def setData(self, data):
        self.data = data

    def formatmessageLine(self, fqdd, msg):
        return "FQDD = " + fqdd + ", Message = " + msg

    def addCriticalFault(self, comp, fqdd, msg):
        if comp in self.faultcriticaldict:
            self.faultcriticaldict.get(comp).append(self.formatmessageLine(fqdd, msg))
        else:
            self.faultcriticaldict[comp] = [self.formatmessageLine(fqdd, msg)]
        return self

    def addWarningFault(self, comp, fqdd, msg):

        if comp in self.faultwarningdict:
            self.faultwarningdict.get(comp).append(self.formatmessageLine(fqdd, msg))
        else:
            self.faultwarningdict[comp] = [self.formatmessageLine(fqdd, msg)]
        return self

    def buildWarning(self):
        return self.generateFaultData(self.faultwarningdict, "WARNING")

    def buildCritical(self):
        return self.generateFaultData(self.faultcriticaldict, "CRITICAL")

    def generateFaultData(self, faultdict, status):
        retstr = ""
        if len(faultdict) > 0:
            for comp, messages in faultdict.items():
                retstr = retstr + comp + " = " + status + ", " + "Faults" + " = " + str(len(faultdict.get(comp)))
                retstr = retstr + "<br>" + self.buildfaultmessage(messages, self.wrapindex) + "<br>"
        return retstr

    def buildfaultmessage(self, messages, wrapindex):
        message = ""
        index = 1
        for msg in messages:
            if index <= wrapindex:
                if message == "":
                    message = msg
                else:
                    message = message + "<br>" + msg
            else:
                message = message + ".."
            index = index + 1
        return message

    def build(self):
        return self.buildWarning() + self.buildCritical()


# NGM Specific implementation for Fault
class NGMFaultInfo(NagiosFaultBase):

    # init method
    def __init__(self):
        # Where to pick up fault information from the response
        super(NGMFaultInfo, self).__init__()
        self.componentType = "Subsystem"
        # Components considered for the Fault info display.
        self.validComponent = ['PowerSupply','CMC','Fan','Temperature']
        self.ngmwarningstatus = ['3000']
        self.ngmcriticalstatus = ['2000', '4000', '5000']


    def buildFaultString(self):
        data = self.data.get(self.componentType)
        for subdata in data:
            faultList = subdata.get("FaultList", None);
            self.buildSubSysFault(faultList,subdata)
        return self.fsb.build()

    def buildSubSysFault(self,faultList,subdata):
        if faultList:
            comp = subdata.get("SubSystem", "")
            if comp in self.validComponent:
                self.addFaultMsg(comp,faultList)

    def addFaultMsg(self,comp,faultList):
        for fault in faultList:
            if fault and fault.get("Severity") in self.ngmwarningstatus:
                self.fsb.addWarningFault(comp, fault.get("Fqdd", ""), fault.get("Message", ""))
            if fault and fault.get("Severity") in self.ngmcriticalstatus:
                self.fsb.addCriticalFault(comp, fault.get("Fqdd", ""), fault.get("Message", ""))

# ME4 fault builder
class ME4FaultInfo(NagiosFaultBase):

    # init method
    def __init__(self):
        super(ME4FaultInfo, self).__init__()
        # Where to pick up fault information from the response
        self.componentType = "System"
        # Components considered for the Fault info display.
       # self.validComponent = ['PowerSupply','CMC','Fan','Temperature'];
        self.me4warningstatus = [1]
        self.me4criticalstatus = [2, 3, 4]

    def buildFaultString(self):
        data = self.data.get(self.componentType)
        for subdata in data:
            faultList = subdata.get("unhealthy-component", None);
            self.buildSubSysFault(faultList,subdata)
        return self.fsb.build()

    def buildSubSysFault(self,faultList,subdata):
        if faultList:
            self.addFaultMsg(faultList)

    def addFaultMsg(self,faultList):
        for fault in faultList:
            if fault and fault.get("health-numeric") in self.me4warningstatus:
                self.fsb.addWarningFault(fault.get("component-type"), fault.get("component-id", ""), fault.get("health-reason", ""))
            if fault and fault.get("health-numeric") in self.me4criticalstatus:
                self.fsb.addCriticalFault(fault.get("component-type"), fault.get("component-id", ""), fault.get("health-reason", ""))